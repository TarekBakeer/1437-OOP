
#include <iostream>
#include <fstream>
#include <vector>
#include <cctype>
#include "fireType.h"
#include "waterType.h"
#include "grassType.h"

using namespace std;

// Variables used to set up the menu and initialize characters
int menu1 = 0;
int types[2];
string name[2];
int choice[2];

// Function that displays the first initial menu
void ogMenu() {
    while (true) {
        cout << "Press 1 to start a new game" << endl;
        cout << "Press 2 to load a saved game" << endl;
        cout << "Press 6 to quit" << endl;

        if (!(cin >> menu1)) {
            cout << "Invalid input. Please enter a valid option." << endl;
            cin.clear(); // Clear the fail state
            cin.ignore(); // Ignore the invalid input character
        } else if (menu1 != 1 && menu1 != 2 && menu1 != 6) {
            cout << "Invalid option. Please enter a valid option." << endl;
        } else {
            break; // Valid input
        }
    }
}

// Menu displayed if the user wants to start a new game
void pokemonOptions(int menu1) {
    if (menu1 == 1) {
        cout << "Player 1, pick a Pokemon type:" << endl;
        cout << "1 - Fire Type" << endl;
        cout << "2 - Water Type" << endl;
        cout << "3 - Grass Type" << endl;

        cin >> choice[0];

        cout << "Enter your name!" << endl;
        cin >> name[0];

        cout << "Player 2, pick a Pokemon type:" << endl;
        cout << "1 - Fire Type" << endl;
        cout << "2 - Water Type" << endl;
        cout << "3 - Grass Type" << endl;

        cin >> choice[1];
        cout << "Enter your name!" << endl;
        cin >> name[1];
    }
}
   
  // Function initializing characters if the user wants to start a new game
void initializer(string name[2], int choice[2], Pokemon*& player1, Pokemon*& player2) {
    for (int i = 0; i < 2; i++) {
        if (choice[i] == 1) {
            if (player1 == nullptr) {
                player1 = new fireType(name[i]);
            } else {
                player2 = new fireType(name[i]);
            }
        }
        if (choice[i] == 2) {
            if (player1 == nullptr) {
                player1 = new waterType(name[i]);
            } else {
                player2 = new waterType(name[i]);
            }
        }
        if (choice[i] == 3) {
            if (player1 == nullptr) {
                player1 = new grassType(name[i]);
            } else {
                player2 = new grassType(name[i]);
            }
        }
    }
}

// Function initializing characters if the user wants to load a saved game
void initializeFromInfoFile(Pokemon*& player1, Pokemon*& player2) {
    cout << "Enter a valid file name" << endl;
    string fileName;
    cin >> fileName;
    ifstream inputFile(fileName); // Open file for reading

    string playerName;
    int playerHealth, playerID;

    // Read player1's information
    inputFile >> playerName >> playerHealth >> playerID;
    if (playerID == 1) {
        player1 = new fireType(playerName, playerHealth);
    } else if (playerID == 2) {
        player1 = new waterType(playerName, playerHealth);
    } else if (playerID == 3) {
        player1 = new grassType(playerName, playerHealth);
    }

    // Read player2's information
    inputFile >> playerName >> playerHealth >> playerID;
    if (playerID == 1) {
        player2 = new fireType(playerName, playerHealth);
    } else if (playerID == 2) {
        player2 = new waterType(playerName, playerHealth);
    } else if (playerID == 3) {
        player2 = new grassType(playerName, playerHealth);
    }

    inputFile.close(); // Close the file
    cout << "Player information initialized successfully." << endl;
} 

// Function that determines what effectiveness message to display based on the character types fighting each other
string getMessage(float multiplier) {
    if (multiplier > 1.0) {
        return "Attack was super effective! ";
    } else if (multiplier < 1.0) {
        return "Attack was not very effective! ";
    } else {
        return "Attack was normal effectiveness ";
    }
}

// Function that saves a game in progress
void saveGame(Pokemon*& player1, Pokemon*& player2){
    cout << "Enter file name" << endl;
    string fileName;
    cin >> fileName;
    ofstream outputFile(fileName); // Open file for writing

    outputFile << player1->getName() << " " << player1->getHealth() << " " << player1->getID() << endl;
    outputFile << player2->getName() << " " << player2->getHealth() << " " << player2->getID() << endl;
    outputFile.close(); // Close the file

    cout << "Game saved" << endl;
}

int main() {
    // This table determines the damage multiplier a character's attacks will have.
    // It's indexed by the pokemon types (player1) (player2)

    float effective_table[3][3] = {
        {1.0, .70, 1.25}, // fire
        {1.25, 1.0, .70}, // water
        {.70, 1.25, 1.0}  // grass
    };

    // These booleans are for the water types hibernation ability.
    // If they use hibernation, these will be set to true, which makes the next attack
    // do increased damage. It is then set to false after the attack is finished
    bool super = false; 
    bool super2 = false;

    // Game loop #1 (mainly for menus)
    while (true) { 
        ogMenu();

    // Code for quitting the game
        if (menu1 == 6) { 
            break;
        }

        pokemonOptions(menu1);

        Pokemon* player1 = nullptr;
        Pokemon* player2 = nullptr;

        // Initializing players if starting a new game
        if (menu1 == 1) {
            initializer(name, choice, player1, player2);
            menu1 = 0;
        }

        // Initializing players if loading a saved game
        else if (menu1 == 2) {
            initializeFromInfoFile(player1, player2);
            menu1 = 0;
        }
// Outputs messages that the players have been created
player1->created();
player2->created();

// Game loop 2 (mainly for the fighting logic)
while (true) {
    player1->fightMenu();

    // Calls the pokemon type's 1st attack
    if (player1->getAttackOP() == 1 && !super) {
        float multiplier = effective_table[player1->getID() - 1][player2->getID() - 1]; // Indexing to find effective multiplier
        player2->attacked(player1->attack1() * multiplier); // Implementing multiplier
        cout << getMessage(multiplier); // Outputting the attack effectiveness
    }
    // Super attack1 for water Hibernation
    else if (player1->getAttackOP() == 1 && super && player1->getID() == 2) {
        cout << player1->getName() << " WOKE UP AND IS STRONGER THAN EVER!, 1.35X DAMAGE INCREASE" << endl;
        player1->healed(30);
        if (player1->getHealth() >= 100) {
            player1->setHealth(100);
        }
        float multiplier = effective_table[player1->getID() - 1][player2->getID() - 1];
        player2->attacked(player1->attack1() * multiplier * 1.35);
        cout << getMessage(multiplier);
        super = false;
    }
    // Calls the pokemon type's 2nd attack
    else if (player1->getAttackOP() == 2 && !super) {
        float multiplier = effective_table[player1->getID() - 1][player2->getID() - 1];
        player2->attacked(player1->attack2() * multiplier);
        cout << getMessage(multiplier);
    }
    // Super attack2 for water Hibernation
    else if (player1->getAttackOP() == 2 && super && player1->getID() == 2) {
        cout << player1->getName() << " WOKE UP AND IS STRONGER THAN EVER!, 1.35X DAMAGE INCREASE" << endl;
        player1->healed(30);
        if (player1->getHealth() >= 100) {
            player1->setHealth(100);
        }
        float multiplier = effective_table[player1->getID() - 1][player2->getID() - 1];
        player2->attacked(player1->attack2() * 1.35 * multiplier);
        cout << getMessage(multiplier);
        super = false;
    }
        //headbutt for firetype
    else if (player1->getAttackOP() == 3 && !super && player1->getID() == 1) {
         player2->attacked(player1->attack3());
}
        // Hibernation setter
    else if (player1->getAttackOP() == 3 && player1->getID() == 2) {
       player1->attack3();
       super = true;
}
        // Blood copy
    else if (player1->getAttackOP() == 3 && player1->getID() == 3 && player1->getID() != 1) {
        player1->setHealth(player2->getHealth());
        player1->attack3();
}   //healing
    else if (player1->getAttackOP() == 4) {
        player1->healed(player1->attack4());
}
    //winner message
    if (player1->getHealth() <= 0) {
         cout << player2->getName() << " survives and wins the game!" << endl;
         cout << endl;
            break;
}
    //death message
    else if (player2->getHealth() <= 0) {
         cout << player1->getName() << " killed " << player2->getName() << "! " << player1->getName() << " Wins!" << endl;
         cout << endl;
         break;
}
    //saving game
    if (player1->getAttackOP() == 5) {
         saveGame(player1, player2);
         exit(-1);
}
    //quitting game
    if (player1->getAttackOP() == 6) {
         exit(-1);
}

//player 2's turn
player2->fightMenu();

          // Calls the pokemon type's 1st attack
    if (player2->getAttackOP() == 1 && !super2) {
         float multiplier = effective_table[player2->getID()-1][player1->getID()-1];
         player1->attacked(player2->attack1() * multiplier);
         cout << getMessage(multiplier);
}
          // Super attack1 for water Hibernation
    else if (player2->getAttackOP() == 1 && super2 && player2->getID() == 2) {
            cout << player2->getName() << " WOKE UP AND IS STRONGER THAN EVER!, 1.35X DAMAGE INCREASE" << endl;
            player2->healed(30);
    if (player2->getHealth() >= 100) {
        player2->setHealth(100);
    }
         float multiplier = effective_table[player2->getID()-1][player1->getID()-1];
         player1->attacked(player2->attack1() * 1.35 * multiplier);
            cout << getMessage(multiplier);
            super2 = false;
}
        //Calls the pokemon type's 2nd attack
    else if (player2->getAttackOP() == 2 && !super2) {
            float multiplier = effective_table[player2->getID()-1][player1->getID()-1];
            player1->attacked(player2->attack2() * multiplier);
            cout << getMessage(multiplier);
}
        // Super attack2 for water Hibernation
    else if (player2->getAttackOP() == 2 && super2 && player2->getID() == 2) {
            cout << player2->getName() << " WOKE UP AND IS STRONGER THAN EVER!, 1.35X DAMAGE INCREASE" << endl;
         player2->healed(30);
    if (player2->getHealth() >= 100) {
        player2->setHealth(100);
    }
            float multiplier = effective_table[player2->getID()-1][player1->getID()-1];
            player1->attacked(player2->attack2() * 1.35 * multiplier);
            cout << getMessage(multiplier);
    super2 = false;
}
         // Headbutt
    else if (player2->getAttackOP() == 3 && !super2 && player2->getID() == 1) {
         player1->attacked(player2->attack3());
}
        // Hibernation setter
    else if (player2->getAttackOP() == 3 && player2->getID() == 2) {
        player2->attack3();
        super2 = true;
}
        // Blood copy
    else if (player2->getAttackOP() == 3 && player2->getID() == 3 && player2->getID() != 1) {
         player2->setHealth(player1->getHealth());
         player2->attack3();
}
        //healing
    else if (player2->getAttackOP() == 4) {
            player2->healed(player2->attack4());
}
        //saving game
    if (player2->getAttackOP() == 5) {
          saveGame(player1, player2);
          exit(-1);
}   
        //quitting game
    if (player2->getAttackOP() == 6) {
         exit(-1);
}
        //winner message
    if (player2->getHealth() <= 0) {
         cout << player1->getName() << " survives and wins the game!" << endl;
            cout << endl;
                break;
}
        //death message
    else if (player1->getHealth() <= 0) {
         cout << player2->getName() << " killed " << player1->getName() << "! " << player2->getName() << " Wins!" << endl;
         cout << endl;
             break;
}

}
}
//end of program!
return 0;
}