#include <iostream>
#include <vector>
#include "PokemonBaseClass.h"
using namespace std;

class fireType : public Pokemon {
private:
    int round;

public:
//Constructors
    fireType(string name) : Pokemon(name) {}
    fireType(string name, int health) : Pokemon(name, health) {}

    // message showing creation of fire type pokemon
    void created() {
        cout << getName() << ", the FIRE type has " << getHealth() << "HP and is ready to burn!" << endl;
        cout << endl;
    }

    // Display fight menu for fireType Pokemon
    void fightMenu() {
        cout << getName() << "'s turn, attack!" << endl;
        cout << getName() << ", you have " << getHealth() << " HP, Pick an attack wisely!" << endl;
        cout << "1 - fireball ------- 2 - flamethrower" << endl;
        cout << "3 - headbutt ------- 4 - coal" << endl;
        cout << "5 - save and exit ------- 6 - quit" << endl;
        cout << endl;
        cin >> attackOP;
    }

    // fireball
    int attack1() {
        health += 15;
        if (health >= 100) {
            health = 100;
            cout << getName() << " used fireball and gained 15 health. Total HP: 100" << endl;
        } else {
            cout << getName() << " used fireball and gained 15 health. Total HP: " << health << endl;
        }
        return -25;
    };

//flamethrower
    int attack2() {
        cout << getName() << " used flamethrower!" << endl;
        return -45;
    };

//headbutt
    int attack3() {
        health -= 30;
        if (health <= 0) {
            cout << getName() << " Killed themselves!" << endl;
            return 0;
        } else {
            cout << getName() << " used headbutt and hurt themselves! " << getName() << " has " << getHealth() << " HP!" << endl;
            return -60;
        }
    }

//coal
    int attack4() {
        cout << getName() << " used coal!" << endl;
        return 30;
    };

//returns ID for fire type 
    int getID() {
        return 1;
    }
};
