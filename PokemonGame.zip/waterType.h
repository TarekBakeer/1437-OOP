#include <iostream>
#include <vector>
#include "PokemonBaseClass.h"
using namespace std;

class waterType : public Pokemon {
private:
    int round;

public:

    // Constructors
    waterType(string name) : Pokemon(name) {}
    waterType(string name, int health) : Pokemon(name, health) {}

//message showing creation of water type
    void created() {
        cout << getName() << ", the WATER type has " << getHealth() << "HP and is ready to swim!" << endl;
        cout << endl;
    }

//water type fight menu
    void fightMenu() {
        cout << getName() << "'s turn, attack!" << endl;

        cout << getName() << ", you have " << getHealth() << " HP, Pick an attack wisely!" << endl;
        cout << "1 - splash ------- 2 - tsunami" << endl;
        cout << "3 - hibernation ------- 4 - fish" << endl;
        cout << "5 - save and exit ------- 6 - quit" << endl;
        cout << endl;
        cin >> attackOP;
    }

//splash attack

    int attack1() {
        health += 15;
        if (health >= 100) {
            health = 100;
            cout << getName() << " used splash and gained 15 health. Total HP: 100" << endl;
        } else {
            cout << getName() << " used splash and gained 15 health. Total HP: " << health << endl;
        }

        return -25;
    };

// tsunami attack
    int attack2() {
        cout << getName() << " used tsunami!" << endl;
        return -45;
    };

//hibernation
    int attack3() {
        cout << getName() << " used hibernation and is asleep. +30HP!" << endl;
        return 0;
    };

//fish
    int attack4() {
        cout << getName() << " used fish!" << endl;
        return 30;
    };

//returns ID of water type
    int getID() {
        return 2;
    }
};
