#include <iostream>
#include <vector>
#include "PokemonBaseClass.h"
using namespace std;

class grassType : public Pokemon {
private:
    int round;

public:

    // Constructors
    grassType(string name) : Pokemon(name) {}
    grassType(string name, int health) : Pokemon(name, health) {}

//message showing creation of grass type
    void created() {
        cout << getName() << ", the GRASS type has " << getHealth() << "HP and is ready to tangle!" << endl;
        cout << endl;
    }

//grass type fight menu
    void fightMenu() {
        cout << getName() << "'s turn, attack!" << endl;
        cout << getName() << ", you have " << getHealth() << " HP, energy! Pick an attack wisely!" << endl;
        cout << "1 - leaf slap ------- 2 - root choke" << endl;
        cout << "3 - blood copy ------- 4 - seed" << endl;
        cout << "5 - save and exit ------- 6 - quit" << endl;
        cout << endl;
        cin >> attackOP;
    }

//leaf slap attack
    int attack1() {
        health += 15;
        if (health >= 100) {
            health = 100;
            cout << getName() << " used leaf slap and gained 15 health. Total HP: 100" << endl;
        } else {
            cout << getName() << " used leaf slap and gained 15 health. Total HP: " << health << endl;
        }
        return -25;
    };

//root choke attack
    int attack2() {
        cout << getName() << " used root choke!" << endl;
        return -45;
    };

//blood copy
    int attack3() {
        cout << getName() << " used blood copy! You now have the same health as your opponent (" << getHealth() << ")HP!" << endl;
        return 0;
    };

//seed
    int attack4() {
        cout << getName() << " used seed!" << endl;
        return 30;
    };

//returns ID of grass type
    int getID() {
        return 3;
    }
};
