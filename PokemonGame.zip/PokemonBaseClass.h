#pragma once

#include <iostream>
#include <vector>

using namespace std;

class Pokemon {
private:
    string name;
    string fileName;

protected:
    int health;
    int attackOP;
    int ID;

public:
    // Constructors
    Pokemon(string inputName) : name(inputName), health(100) {}
    Pokemon(string savedName, int savedHealth) : name(savedName), health(savedHealth) {}

    // Pure virtual functions
    virtual void created() = 0;
    virtual void fightMenu() = 0;
    virtual int attack1() = 0;
    virtual int attack2() = 0;
    virtual int attack3() = 0;
    virtual int attack4() = 0;
    virtual int getID() = 0;

    //  handling attacks 
    void attacked(int f) {
        health += f;
        cout << getName() << " has been hit!" << endl;
    }
    //handling healing
    void healed(int g) {
        health += g;
        if (health >= 100) {
            cout << getName() << " gained health! total health is 100!" << endl;
            health = 100;
        } else {
            cout << getName() << " gained health! total health is " << getHealth() << "!" << endl;
        }
    }

    void setHealth(int d) {
        health = d;
    }

    string getName() {
        return name;
    }

    int getHealth() {
        return health;
    }
// returns attack option
    int getAttackOP() {
        return attackOP;
    }
//retunrs ID of pokemon type, used to determine effectiveness of attacks
    void setID(int l) {
        ID = l;
    }
};
